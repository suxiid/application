@extends('admin')
@section('content')
    test
@endsection