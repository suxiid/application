<header class="info-header">
    <div class="row">
        <div class="col-md-12"><h4>KENTARO AUTO ENGINEERING (PVT.) LTD.</h4></div>
        <div class="col-md-12"><p>395, Colombo Road, Boralesgamuwa Pepiliyana.</p></div>
    </div>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-3"><p>Tel: +94 (11)0000000</p></div>
        <div class="col-md-3"><p>Fax: +94 (11)0000000</p></div>
        <div class="col-md-3"></div>
    </div>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-3"><p>Email: kentaro@kentaro.lk</p></div>
        <div class="col-md-3"><p>Website: www.kentaro.lk</p></div>
        <div class="col-md-3"></div>
    </div>
</header>
<hr>