<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GrnDetail extends Model
{
    //
}
